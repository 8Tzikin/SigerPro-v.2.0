# Manual de Usuario — SIGER PRO v2.0

**Sistema de Gestión de Riesgos · AIES-SOARG / CEPA**

---

## Acceso al sistema

1. Abre `index.html` en **Google Chrome** o **Microsoft Edge**
2. Ingresa usuario y contraseña
3. Clic en **Iniciar Sesión**

---

## Dashboard

Vista general con KPIs (total reportes, en seguimiento, cerrados, investigados), gráficas de tipos de ocurrencia, estado, probabilidad y entidad de origen, y tabla de los últimos reportes.

---

## Registro de Reportes

### Lista
- **Buscar** por texto libre · **Filtrar** por estado, tipo o probabilidad
- **Scroll interno** en la tabla — los filtros y paginación quedan fijos
- 25 registros por página

### Acciones por fila
| Botón | Acción |
|---|---|
| Ver | Modal de detalle completo |
| Editar | Formulario de edición (admin/superadmin) |
| PDF | Genera Formato RSC |
| 📎 Evidencia | Gestiona archivos PDF adjuntos |
| × | Elimina el reporte (solo superadmin) |

---

## Nuevo Reporte

1. Menú lateral → **Nuevo Reporte**
2. Completa los campos obligatorios (*): Fecha, Reportado Por, Tipo de Ocurrencia, Descripción
3. Al seleccionar el Tipo, la Regulación y Normativa se rellenan solos
4. En la pestaña **Evaluación de Riesgo**, selecciona Probabilidad y Severidad → el Índice se calcula automáticamente
5. Clic en **Guardar Reporte**

### Agregar nuevo Tipo de Ocurrencia
Clic en el botón **`+ Nuevo`** junto al selector → ingresa nombre, regulación y normativa opcionales → **Agregar y Seleccionar**.

### Agregar nuevo Tipo de Reporte
Mismo procedimiento con el botón **`+ Nuevo`** junto al selector de Tipo de Reporte.

---

## Generar PDF (Formato RSC)

1. Lista → botón **PDF** en la fila del reporte
2. Ingresa nombres de firma (Elaborado por y Autorizado por son obligatorios)
3. Clic en **Generar PDF** → **Ctrl+P** para imprimir o guardar

---

## Evidencias PDF

1. Lista → botón **📎 Evidencia**
2. Arrastra un PDF o haz clic para seleccionar (máx. 10 MB)
3. Descarga: ícono ⬇ · Eliminar: ícono 🗑
4. Las evidencias aparecen en la Sección 5 del PDF RSC generado

---

## Indicadores de Desempeño

1. Menú → **Indicadores**
2. Selecciona cuántos indicadores ver (Alto o Bajo Impacto)
3. Elige el tipo en cada slot → aparece el gauge con análisis estadístico

**Niveles de desviación estándar:**
- 🟢 **Normal:** valor ≤ Prom+1σ
- 🟡 **Atención:** entre Prom+1σ y Prom+2σ
- 🟠 **Alerta:** entre Prom+2σ y Prom+3σ
- 🔴 **Crítico:** valor > Prom+3σ

Los gauges son responsivos y se adaptan al tamaño de pantalla.

---

## Importar desde Excel/CSV

1. Menú → **Importar Excel**
2. Descarga la plantilla si es la primera vez
3. Arrastra el archivo `.xlsx` o `.csv`
4. Verifica la vista previa y confirma la importación

---

## Datos Históricos

Para activar el análisis estadístico comparativo:

1. Menú → **Datos Históricos**
2. Selecciona el año
3. Arrastra el archivo CSV/XLSX de ese año
4. Clic en **Guardar en Histórico**

---

## Bases Guardadas (Snapshots)

- **Guardar versión:** Menú → **Guardar versión** → ingresa nombre
- **Restaurar:** Menú → **Bases guardadas** → **Cargar**

---

## Respaldo en D:\

1. Menú → **Respaldo en D:\**
2. Clic en **Seleccionar carpeta en D:\**
3. Guarda automáticamente cada 5 minutos
4. Restaurar: **Restaurar desde archivo de respaldo (.json)**

Requiere Chrome o Edge 86+.

---

## Gestión de Usuarios *(admin/superadmin)*

- **Agregar:** Nuevo Usuario → completar campos → Guardar *(solo superadmin)*
- **Editar:** botón Editar en la fila del usuario
- **Eliminar:** botón × *(solo superadmin)*
- Dejar contraseña en blanco al editar para no cambiarla

---

## Cerrar Sesión

Botón **Salir** en la topbar o **Cerrar Sesión** en el pie del sidebar.
Los datos se guardan automáticamente al cerrar sesión.
