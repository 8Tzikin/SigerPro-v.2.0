# Formato de Importación — SIGER PRO v2.0

---

## Columnas del archivo

| # | Nombre de columna | Campo | Requerido | Tipo |
|---|---|---|:---:|---|
| 1 | `NO.` | `no` | Sí | Número entero |
| 2 | `FECHA` | `fecha` | Sí | YYYY-MM-DD / DD/MM/YYYY / serial Excel |
| 3 | `FORMA DE REPORTE` | `formaReporte` | No | Texto |
| 4 | `REPORTE PRESENTADO POR:` | `reportadoPor` | Sí | Texto |
| 5 | `ENTIDAD DE ORIGEN DE REPORTE` | `entidad` | No | Texto |
| 6 | `REPORTE/TEXTO` | `texto` | No | Texto |
| 7 | `TIPO DE REPORTE` | `tipoReporte` | No | Texto |
| 8 | `TIPO DE OCURRENCIA/PELIGRO` | `tipoOcurrencia` | Sí | Texto |
| 9 | `REGULACIÓN APLICABLE` | `regulacion` | No | Texto |
| 10 | `NORMATIVA AIES-SOARG` | `normativa` | No | Texto |
| 11 | `CAUSA RAIZ` | `causaRaiz` | No | Texto |
| 12 | `PROBABILIDAD DE RIESGO` | `probabilidad` | No | 1–5 |
| 13 | `SEVERIDAD DE RIESGO` | `severidad` | No | A–E |
| 14 | `ÍNDICE DE RIESGO /ACEPTABILIDAD` | `indiceRiesgo` | No | Ej: 3C |
| 15 | `ACCIONES APLICADAS` | `acciones` | No | Texto |
| 16 | `RESPONSABILIDAD` | `responsabilidad` | No | Texto |
| 17 | `¿SE INVESTIGA ?` | `seInvestiga` | No | SI / NO |
| 18 | `SEGUIMIENTO POR PARTE DE SMS` | `seguimientoSMS` | No | Texto |
| 19 | `FECHA DE IMPLEMENTACIÓN` | `fechaImpl` | No | Fecha |
| 20 | `ÍNDICE DE RIESGO RESULTANTE` | `indiceResultante` | No | Ej: 1C |
| 21 | `RETROALIMENTACIÓN` | `retroalimentacion` | No | Texto |
| 22 | `PROCESADO EN FORMATO RSC` | `procesadoRSC` | No | SI / NO |
| 23 | `ESTADO` | `estado` | No | CIERRE / SEGUIMIENTO |
| 24 | `ACEPTACIÓN` | `aceptacion` | No | Texto |

---

## Matriz de Riesgo — Severidad

| Letra | Nombre | Descripción |
|---|---|---|
| A | Catastrófico | Destrucción de equipamiento, muertes múltiples |
| B | Peligroso | Reducción importante de márgenes, lesiones graves |
| C | **Grave** | Reducción significativa, incidente serio |
| D | Menor | Interferencia, limitaciones operativas |
| E | Insignificante | Pocas consecuencias |

---

## Formato de fechas aceptados

| Formato | Ejemplo |
|---|---|
| ISO 8601 | `2026-01-15` |
| DD/MM/YYYY | `15/01/2026` |
| Serial Excel | `46027` |

---

## Ejemplo CSV mínimo

```csv
NO.,FECHA,REPORTE PRESENTADO POR:,TIPO DE OCURRENCIA/PELIGRO,PROBABILIDAD DE RIESGO,SEVERIDAD DE RIESGO,ESTADO
1,2026-01-10,Juan Pérez,FOD EN PISTA,3,C,CIERRE
2,2026-01-15,María García,FAUNA EN EL ÁREA DE MOVIMIENTO,4,B,SEGUIMIENTO
```

---

## Notas importantes

- El archivo debe estar codificado en **UTF-8** (usar "CSV UTF-8 (con BOM)" en Excel)
- Si el XLSX tiene múltiples hojas, el sistema detecta automáticamente la que contiene los datos. Para mayor fiabilidad, nómbrala **"MATRIZ"**
- Activa **"Omitir duplicados"** durante la importación para evitar registros repetidos por número de reporte
