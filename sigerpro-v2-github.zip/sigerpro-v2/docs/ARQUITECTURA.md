# Arquitectura Técnica — SIGER PRO v2.0

## Filosofía

Aplicación **Single-File SPA** — HTML + CSS + JS en un solo `index.html`. Sin bundler, sin framework, sin dependencias de runtime. Máxima portabilidad: funciona desde USB, escritorio o servidor estático.

---

## Estructura interna de `index.html`

```
index.html
├── <head>
│   ├── Google Fonts (IBM Plex Sans, IBM Plex Mono)
│   └── <style> (~580 líneas CSS)
│       ├── Variables CSS (paleta CEPA)
│       ├── Layout (sidebar + topbar + main)
│       ├── Componentes (cards, badges, chips, modales)
│       ├── Tabla con scroll interno (#pg-lista)
│       ├── Gauges responsivos (CSS Grid)
│       └── Evidencias PDF
│
└── <body>
    ├── #login-screen
    ├── #app-shell
    │   ├── #sidebar (nav + footer usuario)
    │   └── #main-area
    │       ├── .topbar (sticky)
    │       ├── #pg-dashboard
    │       ├── #pg-lista (scroll interno)
    │       ├── #pg-nueva
    │       ├── #pg-indicadores (gauges responsivos)
    │       ├── #pg-matriz
    │       ├── #pg-normativa
    │       └── #pg-usuarios
    │
    ├── Modales (13 modales)
    │   ├── m-detalle, m-editar, m-import
    │   ├── m-add-tipo, m-add-tiporeporte (tipos dinámicos)
    │   ├── m-evidencia (adjuntar PDFs)
    │   ├── m-pdf-rsc, m-save-snap, m-snapshots
    │   ├── m-historico, m-backup, m-usuario
    │   └── m-add-tipo, m-add-tiporeporte
    │
    └── <script> (~3500 líneas JS)
        ├── Constantes y datos (NORMATIVA_DATA, RISK_MATRIX, SEV_DESC)
        ├── localStorage helpers
        ├── Motor Canvas (mkChart, _drawBar, _drawDoughnut, drawGauge)
        ├── Módulo Indicadores (_indRender, calcIndicadorStats con 3σ)
        ├── Tipos dinámicos (_loadTiposOcurrencia, guardarNuevoTipo, etc.)
        ├── Login / Auth
        ├── Navegación (navTo)
        ├── Dashboard (renderDashboard)
        ├── Lista / CRUD (renderLista, verDetalle, abrirEditar, eliminar)
        ├── Nuevo Reporte (guardarNuevo, calcIndice, autoFillNormativa)
        ├── PDF RSC (imprimirRSC)
        ├── Evidencias (abrirEvidencias, _evProcesarArchivo, _evDescargar)
        ├── Importación XLSX/CSV (_xlsxToRows, confirmarImport)
        ├── Exportación CSV (exportarExcel)
        ├── Snapshots y Datos Históricos
        ├── Respaldo en D:\ (File System Access API)
        ├── Gestión de Usuarios
        └── Init (initApp)
```

---

## Persistencia (localStorage)

| Clave | Contenido |
|---|---|
| `sigerpro_db_v2` | Array de reportes activos |
| `sigerpro_hist_v1` | Registros históricos por año |
| `sigerpro_users_v1` | Lista de usuarios |
| `sigerpro_ind_prefs_v1` | Preferencias de gauges |
| `sigerpro_snap_index` | Índice de snapshots |
| `sigerpro_snap_data_{id}` | Datos de cada snapshot |
| `sigerpro_evidencias_v1` | Evidencias PDF (base64) |
| `sigerpro_tipos_ocurrencia_v1` | Tipos de ocurrencia personalizados |
| `sigerpro_tipos_reporte_v1` | Tipos de reporte personalizados |

---

## Análisis estadístico (Indicadores)

```
Datos: conteos mensuales del tipo de ocurrencia (DB actual + histórico)

μ (Promedio)  = Σ(conteos_mensuales) / n_meses
σ (DVSTD)     = √( Σ(xi - μ)² / n )

Prom + 1DVSTD = μ + 1σ  →  🟡 Atención
Prom + 2DVSTD = μ + 2σ  →  🟠 Alerta
Prom + 3DVSTD = μ + 3σ  →  🔴 Crítico
```

---

## Gauges responsivos

Los gauges usan Canvas API puro. El tamaño del canvas se calcula en tiempo real:

```javascript
cardW  = cardEl.clientWidth - 28    // ancho real menos padding
cardH  = Math.round(cardW * 0.58)   // ratio óptimo para semicírculo
R      = Math.min(W * 0.42, cy * 0.88)  // radio proporcional
arcW   = Math.max(10, R * 0.13)     // grosor del arco proporcional
```

CSS Grid con `auto-fill` y `minmax(240px, 1fr)` distribuye las tarjetas uniformemente.

---

## Lector XLSX nativo (sin SheetJS)

1. Parseo ZIP: busca entradas `PK\x03\x04`
2. Descompresión: `DecompressionStream('deflate-raw')`
3. Shared Strings: parsea `xl/sharedStrings.xml`
4. Workbook/rels: mapea nombres de hojas a rutas XML
5. Autodetección de hoja con datos (señales: `NO.`, `TIPO DE OCURRENCIA`)
6. Autodetección de fila de encabezado

---

## Compatibilidad

| Feature | Chrome | Edge | Firefox | Safari |
|---|:---:|:---:|:---:|:---:|
| App completa | ✅ 86+ | ✅ 86+ | ✅ 90+ | ✅ 14+ |
| Importar XLSX | ✅ | ✅ | ✅ | ✅ |
| Evidencias PDF | ✅ | ✅ | ✅ | ✅ |
| Respaldo en D:\ | ✅ | ✅ | ❌ | ❌ |
